module.exports.brush_teeth = [
    "Java was first introduced to the world in 1995 by Sun Microsystems",
    "Lambda expressions were first included in Java 8"
];
 
module.exports.wear_pajamas = [
    "Ionic Framework is a hybrid mobile development framework that sits on top of Apache Cordova",
    "The first version of Ionic Framework uses Angular 1 where as the second version uses Angular 2",
    "Ionic Framework lets you develop applications with HTML and JavaScript"
];